import React, { Component } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import logo from './logo.png';
import './App.css';
import AirportChooser from "./component/airportchooser";

class App extends Component {
  render() {
    return (
      <div className="App">

        <Container>
          <header className="App-header">
            <Row>
              <Col xs={12} sm={12} md={12} lg={2} className="logo-col nopadd">
                <img src={logo} className="App-logo" alt="logo" />
              </Col>
              <Col xs={12} sm={12} md={12} lg={10} className="head-welcome">
                Welcome!
                </Col>
            </Row>
          </header>
          <AirportChooser />

        </Container>
      </div>
    );
  }
}

export default App;
