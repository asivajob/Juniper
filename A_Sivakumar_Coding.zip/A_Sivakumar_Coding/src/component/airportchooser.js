import React, { Component, useState } from 'react';
import { Row, Col, Dropdown, FormControl } from "react-bootstrap";
import AirportDetails from "./airportdetails";
import Loader from "./loader";

class airportChooser extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            isLoaded: false,
            data: "",
            individualListItems: ""
        }
    }
    async componentDidMount() {
        const URL = "https://gist.githubusercontent.com/tdreyno/4278655/raw/7b0762c09b519f40397e4c3e100b097d861f5588/airports.json";
        await fetch(URL)
            .then(response => response.json())
            .then(data => this.setState({ data, isLoaded: true }));
    }

    showDetails = (item) => {
        this.setState({individualListItems: item})
    }

    render() {
        // The forwardRef is important!!
        // Dropdown needs access to the DOM node in order to position the Menu
        const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
            <a
                href="#!"
                ref={ref}
                onClick={(e) => {
                    e.preventDefault();
                    onClick(e);
                }}
            >
                {children}
      &#x25bc;
            </a>
        ));

        // forwardRef again here!
        // Dropdown needs access to the DOM of the Menu to measure it
        const CustomMenu = React.forwardRef(
            ({ children, style, className, 'aria-labelledby': labeledBy }, ref) => {
                const [value, setValue] = useState('');

                return (
                    <div
                        ref={ref}
                        style={style}
                        className={className}
                        aria-labelledby={labeledBy}
                    >
                        <FormControl
                            autoFocus
                            className="mx-3 my-2 w-auto"
                            placeholder="Type to filter..."
                            onChange={(e) => setValue(e.target.value)}
                            value={value}
                        />
                        <ul className="list-unstyled">
                            {React.Children.toArray(children).filter(
                                (child) =>
                                    !value || child.props.children.toLowerCase().startsWith(value),
                            )}
                        </ul>
                    </div>
                );
            },
        );
        return (
            <>
            { !this.state.isLoaded &&
                <Loader />
            }
            { this.state.isLoaded &&
            <Row>
                <Col lg={12} md={12} xs={12} sm={12} className="dropdown-col mtop-20">
                    <Dropdown>
                        <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components">
                            Click here to explore more
                        </Dropdown.Toggle>
                        <Dropdown.Menu as={CustomMenu}>
                            {this.state.data && this.state.data.map((item, i) =>
                                <Dropdown.Item eventKey={i} key={i}>
                                    <div onClick={()=> this.showDetails(item)}>{item.name}</div>
                                </Dropdown.Item>
                            )}
                            {
                            /* <Dropdown.Item eventKey="1">Red</Dropdown.Item>
                            <Dropdown.Item eventKey="2">Blue</Dropdown.Item>
                            <Dropdown.Item eventKey="3" active>
                                Orange
                            </Dropdown.Item>
                            <Dropdown.Item eventKey="1">Red-Orange</Dropdown.Item> */}
                        </Dropdown.Menu>
                    </Dropdown>
                </Col>
                {this.state.individualListItems &&
                    <AirportDetails individualListItems={this.state.individualListItems} />
                }                
            </Row>
            }
            </>
        );
    }
}
export default (airportChooser);