import React, { Component } from 'react';
import { Col, Jumbotron, Card, CardDeck } from "react-bootstrap";
import Loader from "./loader";
import runway from "../runway.png";
import elivator from "../elivator.png";
import location from "../location.png";

class airportDetails extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            isLoaded: false,
            data: "",
            individualListItems: ""
        }
    }

    render() {
        const items = this.props.individualListItems;
        return (
            <>
            { items &&
            <Col lg={12} md={12} xs={12} sm={12} className="individual-list-col mtop-20">
                <Jumbotron>
                    <h1>Hello, Welcome to {items.name} {items.type} !</h1>
                    <CardDeck className="mtop-20">
                        <Card>
                            <Card.Img variant="top" src={runway} height="300" width="100" alt=""/>
                            <Card.Body>
                                <Card.Title>Capacity</Card.Title>
                                <Card.Text>
                                    This airport have a capacity of {items.carriers} carriers
                                    {items.runway_length && <>, with runway of {items.runway_length} length </> }.
                                </Card.Text>
                            </Card.Body>
                            <Card.Footer>
                                <small className="text-muted">Last updated 3 mins ago</small>
                            </Card.Footer>
                        </Card>
                        <Card>
                            <Card.Img variant="top" src={elivator} height="300" width="100" alt=""/>
                            <Card.Body>
                                <Card.Title>Details</Card.Title>
                                <Card.Text>
                                    This service {items.direct_flights} directs flight with {items.elev} elevators
                                </Card.Text>
                            </Card.Body>
                            <Card.Footer>
                                <small className="text-muted">Last updated 3 mins ago</small>
                            </Card.Footer>
                        </Card>
                        <Card>
                            <Card.Img variant="top" src={location} height="300" width="100" alt="" />
                            <Card.Body>
                                <Card.Title>Location</Card.Title>
                                <Card.Text>
                                    This is airport locates {items.lat} lat {items.lon} lon, in {items.state} state / {items.country}
                                </Card.Text>
                            </Card.Body>
                            <Card.Footer>
                                <small className="text-muted">Last updated 3 mins ago</small>
                            </Card.Footer>
                        </Card>
                    </CardDeck>
                </Jumbotron>
            </Col>
            }
            {!items &&             
             <Loader />
            } 
            </>
        );
    }
}
export default (airportDetails);